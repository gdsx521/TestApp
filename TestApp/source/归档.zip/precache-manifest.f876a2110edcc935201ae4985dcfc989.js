self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3dfb5c6123afe14ad0d1ede0f6e07e28",
    "url": "./index.html"
  },
  {
    "revision": "c7ccc5075dc86770547f",
    "url": "./static/css/2.5cf0e81c.chunk.css"
  },
  {
    "revision": "8fd1591fb019377aaac6",
    "url": "./static/css/main.e5adf735.chunk.css"
  },
  {
    "revision": "c7ccc5075dc86770547f",
    "url": "./static/js/2.5b67cf3a.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "./static/js/2.5b67cf3a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8fd1591fb019377aaac6",
    "url": "./static/js/main.20c9b931.chunk.js"
  },
  {
    "revision": "21fbd6212f08c1ca4193",
    "url": "./static/js/runtime-main.e178b3e7.js"
  },
  {
    "revision": "20720c3ac567a72d0ef973d2e703dfae",
    "url": "./static/media/DIN-Bold.20720c3a.otf"
  },
  {
    "revision": "6bc2ba289518904b3578741ed012e2a6",
    "url": "./static/media/PingFangSCMedium.6bc2ba28.ttf"
  }
]);